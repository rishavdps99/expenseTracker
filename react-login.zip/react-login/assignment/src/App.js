import React, { Component } from 'react'
import './App.css'

export class App extends Component {
  constructor(props)
  {

      super(props)

      this.state={
          name:"",
          locality:"",
          mail:"",
          model:"",
      }
      this.handleSubmit=this.handleSubmit.bind(this)
  }
  firsthandle=(e)=>{
    this.setState({
        name:e.target.value
    })
  }

  localityhandle=(e)=>{
      this.setState({
          locality:e.target.value
      })
    }

    mailhandle=(e)=>{
      this.setState({
          mail:e.target.value
      })
    }

    modelhandle=(e)=>{
      this.setState({
          name:e.target.value
      })
    }

  handleSubmit=(e)=>{
     alert(`${this.state.name} Submitted Successfully`)
     this.setState({
         name:"",
         locality:"",
         mail:"",
         model:""
     })
     e.preventDefault()
  }

  render() {
      return (
          <div class="container">
             <div class="App">
          <form  onSubmit={this.handleSubmit}>
            <h1><b> Get a Qubi Form</b></h1>
           <div class="form-group">
           <label>Name</label>
           <input type="text" class="form-control" placeholder="Your Name" value={this.state.name} onChange={this.firsthandle}/>
        </div>

        <div class="form-group">
        <label>Locality</label>
        <input type="text" class="form-control" placeholder="Your Locality.." value={this.state.locality} onChange={this.localityhandle}/>

        </div>

        <div class="form-group">
        <label>Email</label>
        <input type="mail" class="form-control" placeholder="Your mail..." value={this.state.mail} onChange={this.mailhandle}/>

        </div>

        <div class="form-group">
        <label> Model Required</label>
        <input type="text" class="form-control" placeholder="Your Requirement" value={this.state.model} onChange={this.modelhandle}/>

        </div>
            <br/>
            <button type="submit" class="btn" placeholder="Submit" value="Submit">Submit</button>
          </form>
          </div>
          </div>
      )
  }
}

export default App
