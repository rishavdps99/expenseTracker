import React, { Component } from 'react'
import './todo.css';

export class Form extends Component {

    constructor(props)
    {

        super(props)

        this.state={
            name:"",
            locality:"",
            mail:"",
            model:"",
        }
        this.handleSubmit=this.handleSubmit.bind(this)
    }
    firsthandle=(e)=>{
      this.setState({
          name:e.target.value
      })
    }

    localityhandle=(e)=>{
        this.setState({
            locality:e.target.value
        })
      }

      mailhandle=(e)=>{
        this.setState({
            mail:e.target.value
        })
      }

      modelhandle=(e)=>{
        this.setState({
            name:e.target.value
        })
      }

    handleSubmit=(e)=>{
       alert(`${this.state.name} Submitted Successfully`)
       this.setState({
           name:"",
           locality:"",
           mail:"",
           model:""
       })
       e.preventDefault()
    }

    render() {
        return (
            <div class="container">
                
            <form class="main-container" onSubmit={this.handleSubmit}>
              <h1> Get a Qubi Form</h1>

              <label>Name</label><input type="text" placeholder="Your Name" value={this.state.name} onChange={this.firsthandle}/>
              <label>Locality</label><input type="text" placeholder="Your Locality.." value={this.state.locality} onChange={this.localityhandle}/>
              <label>Email</label><input type="mail" placeholder="Your mail..." value={this.state.mail} onChange={this.mailhandle}/>
              <label> Model Required</label><input type="text" placeholder="Your Requirement" value={this.state.model} onChange={this.modelhandle}/>
              <br/>
              <input type="submit" value="Submit"/>
            </form>
            </div>
        )
    }
}

export default Form
